Khi người dùng tích chọn Remember me, Cookie sẽ lưu lại tên người dùng với hạn là 30 ngày.
Nếu người dùng tắt trình duyệt và mở lại, khi vào trang info.php,  session hết nhưng vẫn còn cookie, Session sẽ lấy username từ cookie.

Tên đăng nhập demo: user
Mật khẩu: pass